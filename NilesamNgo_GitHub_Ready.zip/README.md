# Nilesam NGO website (GitHub Pages ready)

## Files
- `index.html` — homepage
- `style.css`, `javascript.js` — homepage styling and behavior
- `about.html`, `about.css` — About page
- `donate.html`, `donate.css`, `payment.js` — payment demonstration page
- `login.html`, `login.css` — registration/login demo page
- `images/` — website images

## Upload to GitHub
1. Open your repository: https://github.com/nileshprasad762-alt/NilesamNgo
2. Choose **Add file → Upload files**.
3. Open this extracted folder and upload its CONTENTS (index.html, CSS/JS files, and images folder) into the repository root.
4. Commit changes to the `main` branch.
5. Wait for GitHub Pages to deploy, then refresh https://nileshprasad762-alt.github.io/NilesamNgo/ with Ctrl+F5.

Important: Do not upload the outer ZIP file as the only repository item. Upload the extracted files so `index.html` and `style.css` sit directly in the repository root.

## Notes
- Local Windows image paths were changed to relative `images/...` paths.
- The first duplicate `id="donate"` was renamed so the main Donate link targets the actual donation section.
- The UPI QR page is a front-end demonstration. It can initiate a real UPI payment request; keep the college-project disclaimer visible. It does not verify payments.
- The login form is a front-end demo and does not store accounts or passwords.
